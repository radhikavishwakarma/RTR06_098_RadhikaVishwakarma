#import <Foundation/Foundation.h>	// Similar to stdio.h
#import <Cocoa/Cocoa.h> 			// Similar to Windows.h

// OpenGL related Header files
#import <QuartzCore/CVDisplayLink.h>
#import <OpenGL/gl3.h>
#import <OpenGL/gl3ext.h>

// Header file for Matrix and Transformation related functions
#include "vmath.h"
using namespace vmath;

// Global function declarations
CVReturn myDisplayLinkCallback(CVDisplayLinkRef,
							   const CVTimeStamp *,
							   const CVTimeStamp *,
							   CVOptionFlags,
							   CVOptionFlags *,
							   void *);

// Global Variable declarations
FILE *gpFile = NULL;

enum
{
	AMC_ATTRIBUTE_POSITION = 0,
};

@interface AppDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate>
@end

@interface GLView : NSOpenGLView
-(void)uninitialize;
@end

// Entry-point Function
int main(int argc, char *argv[])
{
	// Code
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];

	NSApp = [NSApplication sharedApplication];

	[NSApp setDelegate:[[AppDelegate alloc]init]];

	[NSApp run];

	[pool release];
	
	return(0);
}

@implementation AppDelegate
{
@private
	NSWindow *window;
	GLView *glView;
}

-(void)applicationDidFinishLaunching:(NSNotification *)notification
{
	// Code
	// Create Log file
	NSBundle *appBundle = [NSBundle mainBundle];
	NSString *appDirPath = [appBundle bundlePath];
	NSString *parentDirPath = [appDirPath stringByDeletingLastPathComponent];
	NSString *logFileNameWithPath = [NSString stringWithFormat:@"%@/Log.txt",parentDirPath];
	const char *pszLogFileNameWithPath = [logFileNameWithPath cStringUsingEncoding:NSASCIIStringEncoding];

	gpFile = fopen(pszLogFileNameWithPath,"w");
	if(gpFile == NULL)
	{
		// Message Box
		NSAlert *alert = [[NSAlert alloc]init];
		[alert setAlertStyle:NSAlertStyleCritical];
		[alert setMessageText:@"Log File Creation Failed!"];
		[alert addButtonWithTitle:@"Exit"];
		[alert runModal];
		[alert release];

		// Exit
		[self release];
		[NSApp terminate:self];
	}
	else
	{
		fprintf(gpFile, "Program Started Successfully!\n");
	}

	// Window
	NSRect winRect = NSMakeRect(0.0, 0.0, 800.0, 600.0);
	window = [[NSWindow alloc]initWithContentRect:winRect
										styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskClosable | NSWindowStyleMaskResizable
										  backing:NSBackingStoreBuffered
										  	defer:NO];

	[window setTitle:@"Radhika Vishwakarma"];
	[window center];

	glView = [[GLView alloc]initWithFrame:winRect];

	[window setContentView:glView];
	[window setDelegate:self];
	[window makeKeyAndOrderFront:self];
}

-(void)applicationWillTerminate:(NSNotification *)notification
{
	// Code
	if(gpFile)
	{
		fprintf(gpFile, "Program Terminated Successfully!\n");
		fclose(gpFile);
		gpFile = NULL;
	}
}

-(BOOL)windowShouldClose:(NSWindow *)aWindow
{
    // code
    [glView uninitialize];
    return(YES);
}

-(void)windowWillClose:(NSNotification *)notification
{
	// Code
	[NSApp terminate:self];
}

-(void)dealloc
{
	// Code
	[glView release];

	[window release];

	[super dealloc];
}

@end

@implementation GLView
{
@private
	CVDisplayLinkRef displayLink;
	int winWidth;
	int winHeight;

	
	// Shader related global variables
	GLuint shaderProgramObject;

	// Triangle
	GLuint vao_triangle;			// Vertex Array Object
	GLuint vbo_position_triangle;	// Vertex Buffer Object

	// Rectangle
	GLuint vao_rectangle;			// Vertex Array Object
	GLuint vbo_position_rectangle;	// Vertex Buffer Object

	// Circle
	GLuint vao_circle;			// Vertex Array Object
	GLuint vbo_position_circle;	// Vertex Buffer Object

	// Graph
	// X-Axis
	GLuint vao_XAxis;
	GLuint vbo_position_XAxis;

	// Y-Axis
	GLuint vao_YAxis;
	GLuint vbo_position_YAxis;

	// Horizontal Lines
	GLuint vao_horizontalLines;
	GLuint vbo_position_horizontalLines;

	// Vertical Lines
	GLuint vao_verticalLines;
	GLuint vbo_position_verticalLines;

	// Constants
	int numberOfLinesEachSide;
	int numberOfTotalLines;
	int numberOfPointsToDrawCircle;

	GLuint mvpMatrixUniform;
	GLuint colorUniform;

	mat4 perspectiveProjectionMatrix;

	// Variables related to toggle shapes
	// Variable related with graph keypress
	BOOL gbGraphKeyPressed;

	// Variable related with triangle keypress
	BOOL gbTriangleKeyPressed;

	// Variable related with square keypress
	BOOL gbSquareKeyPressed;

	// Variable related with circle keypress
	BOOL gbCircleKeyPressed;

	// Variable related with zero keypress 
	BOOL gbZeroKeyPressed;

	}

-(id)initWithFrame:(NSRect)frame
{
	// Code
	self = [super initWithFrame:frame];

	if(self)
	{
		[[self window]setContentView:self];
		
		[self setWantsLayer:YES];
		NSColor *backgroundColor = [NSColor blackColor];
		struct CGColor *bgColor = [backgroundColor CGColor];
		[[self layer]setBackgroundColor:bgColor];

		// Step 1: NSOpenGLPixelFormatAttribute Initialization
		NSOpenGLPixelFormatAttribute attributes[] = 
		{
			NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion4_1Core,
			NSOpenGLPFAScreenMask, CGDisplayIDToOpenGLDisplayMask(kCGDirectMainDisplay),
			NSOpenGLPFANoRecovery,
			NSOpenGLPFAAccelerated,
			NSOpenGLPFAColorSize, 24,
			NSOpenGLPFADepthSize, 24,
			NSOpenGLPFAAlphaSize, 8,
			NSOpenGLPFADoubleBuffer,
			0
		};

		// Step 2: Create NSOpenGLPixelFormat
		NSOpenGLPixelFormat *pixelFormat = [[[NSOpenGLPixelFormat alloc]initWithAttributes:attributes]autorelease];
		
		if(pixelFormat == nil)
		{
			fprintf(gpFile,"NSOpenGLPixelFormat Creation Failed!\n");
			[self uninitialize];
			[self release];
			[NSApp terminate:self];
		}

		// Step 3: Create NSOpenGLContext
		NSOpenGLContext *glContext = [[[NSOpenGLContext alloc]initWithFormat:pixelFormat shareContext:nil]autorelease];

		if(glContext == nil)
		{
			fprintf(gpFile,"NSOpenGLContext Creation Failed!\n");
			[self uninitialize];
			[self release];
			[NSApp terminate:self];
		}

		// Step 4: Set NSOpenGLView's PixelFormat with our created PixelFormat
		[self setPixelFormat:pixelFormat];

		// Step 4: Set NSOpenGLView's OpenGLContext with our created Context
		[self setOpenGLContext:glContext];
	}

	return(self);
}

-(CVReturn)getFrameForTime:(const CVTimeStamp *)outputTime
{
	// Code
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];

	[self drawView];

	[pool release];

	return(kCVReturnSuccess);
}

-(void)prepareOpenGL
{
	// Code
	// Step 1: Call super prepareOpenGL
	[super prepareOpenGL];

	// Step 2: Make the OpenGL Context as Current Context
	[[self openGLContext]makeCurrentContext];

	// Step 3: Set Swap Interval to 1 to Synchronize Arrival of Buffers in Double Buffering, to Avoid Screen tearing
	GLint swapInterval = 1;
	[[self openGLContext]setValues:&swapInterval forParameter:NSOpenGLCPSwapInterval];

	// Step 4: Now call, our initialize function here
	int iResult = [self initialize];

	// Step 5: Start the DisplayLink to Create the Separate Rendering Thread which will Render our View
	// Step A: Create the DisplayLink
	CVDisplayLinkCreateWithActiveCGDisplays(&displayLink);

	// Step B: Set the Callback Function of this DisplayLink
	CVDisplayLinkSetOutputCallback(displayLink, &myDisplayLinkCallback, self);

	// Step C: Convert NSOpenGLPixelFormat into CGLPixelFormatObj
	CGLPixelFormatObj cglPixelFormat = (CGLPixelFormatObj)[[self pixelFormat]CGLPixelFormatObj];

	// Step D: Convert NSOpenGLContext into CGLContext
	CGLContextObj cglContext = (CGLContextObj)[[self openGLContext]CGLContextObj];

	// Step E: Set CGLPixelFormat and CGLContext as Current Display's CGLPixelFormat and CGLContext for this DisplayLink
	CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext(displayLink, cglContext, cglPixelFormat);

	// Step F: Start the DisplayLink (In other words, Start the new Rendering Thread)
	CVDisplayLinkStart(displayLink);
}

-(void)reshape
{
	// Code
	[super reshape];

	// Make the OpenGL Context as Current Context
	[[self openGLContext]makeCurrentContext];

	// Lock the Current CGLContext
	CGLLockContext((CGLContextObj)[[self openGLContext]CGLContextObj]);

	// Variable declarations
	NSRect viewRect = [self bounds];
	winWidth = (int)viewRect.size.width;
	winHeight = (int)viewRect.size.height;

	[self resize:winWidth :winHeight];
	
	// Unlock the Current CGLContext
	CGLUnlockContext((CGLContextObj)[[self openGLContext]CGLContextObj]);
}

-(void)drawView
{
	// Code
	// Make the OpenGL Context as Current Context
	[[self openGLContext]makeCurrentContext];

	// Lock the Current CGLContext
	CGLLockContext((CGLContextObj)[[self openGLContext]CGLContextObj]);

	// Render
	[self display];

	// Update
	[self myUpdate];

	// Swap buffers or Double buffering
	CGLFlushDrawable((CGLContextObj)[[self openGLContext]CGLContextObj]);

	// Unlock the Current CGLContext
	CGLUnlockContext((CGLContextObj)[[self openGLContext]CGLContextObj]);
}

-(void)drawRect:(NSRect)dirtyRect
{
	// Code
	[self drawView];	// To avoid the possibility of flickering
}

-(BOOL)acceptsFirstResponder
{
	// Code
	[[self window]makeFirstResponder:self];

	return(YES);
}

-(void)keyDown:(NSEvent *)event
{
	// Code
	int key = (int)[[event characters]characterAtIndex:0];

	switch(key)
	{
	case 27:
		[self uninitialize];
		[self release];
		[NSApp terminate:self];
		break;

	case 'F':
	case 'f':
		[[self window]toggleFullScreen:self];
		break;

	case 'G':
	case 'g':
		if (gbGraphKeyPressed == FALSE)
		{
			// Show graph
			gbGraphKeyPressed = TRUE;
		}
		else
		{
			// Hide graph
			gbGraphKeyPressed = FALSE;
		}
		break;

	case 'T':
	case 't':
		if (gbTriangleKeyPressed == FALSE)
		{
			// Show triangle
			gbTriangleKeyPressed = TRUE;
		}
		else
		{
			// Hide triangle
			gbTriangleKeyPressed = FALSE;
		}
		break;

	case 'S':
	case 's':
		if (gbSquareKeyPressed == FALSE)
		{
			// Show square
			gbSquareKeyPressed = TRUE;
		}
		else
		{
			// Hide square
			gbSquareKeyPressed = FALSE;
		}
		break;

	case 'C':
	case 'c':
		if (gbCircleKeyPressed == FALSE)
		{
			// Show circle
			gbCircleKeyPressed = TRUE;
		}
		else
		{
			// Hide circle
			gbCircleKeyPressed = FALSE;
		}
		break;

	default:
		break;
	}
}

-(void)mouseDown:(NSEvent *)event
{
	// Code
}

-(int)initialize
{
	// Code
	// Print GL Information
	[self printGLInfo];

	numberOfLinesEachSide = 20;
	numberOfTotalLines = numberOfLinesEachSide * 2;
	numberOfPointsToDrawCircle = 1000;

	gbGraphKeyPressed = FALSE;
	gbTriangleKeyPressed = FALSE;
	gbSquareKeyPressed = FALSE;
	gbCircleKeyPressed = FALSE;
	gbZeroKeyPressed = FALSE;

	// VERTEX SHADER
	// Step 1 : Write the Shader Source Code
	const GLchar* vertexShaderSourceCode =
		"#version 410 core\n" \
		"in vec4 aPosition;\n" \
		"uniform mat4 uMVPMatrix;\n" \
		"void main(void)\n" \
		"{\n" \
			"gl_Position = uMVPMatrix * aPosition;\n" \
		"}\n";

	// Step 2 : Create the Shader Object
	GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);

	// Step 3 : Give the Shader Source Code to the Shader Object
	glShaderSource(vertexShaderObject, 1, (const GLchar**)&vertexShaderSourceCode, NULL);

	// Step 4 : Compile the Shader Programmatically
	glCompileShader(vertexShaderObject);

	// Step 5 : Shader Compilation Error Checking
	GLint status = 0;
	GLint infoLogLength = 0;
	GLchar* szInfoLog = NULL;

	glGetShaderiv(vertexShaderObject, GL_COMPILE_STATUS, &status);
	if (status == GL_FALSE)
	{
		glGetShaderiv(vertexShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0)
		{
			szInfoLog = (GLchar*)malloc(infoLogLength * sizeof(GLchar));
			if (szInfoLog != NULL)
			{
				glGetShaderInfoLog(vertexShaderObject, infoLogLength, NULL, szInfoLog);
				fprintf(gpFile, "Vertex Shader Compilation Log : %s \n", szInfoLog);

				free(szInfoLog);
				szInfoLog = NULL;
			}
		}

		[self release];
		[self uninitialize];
		[NSApp terminate:self];
	}

	// FRAGMENT SHADER
	// Step 1 : Write the Shader Source Code
	const GLchar* fragmentShaderSourceCode =
		"#version 410 core\n" \
		"uniform vec4 uColor;\n" \
		"out vec4 FragColor;\n" \
		"void main(void)\n" \
		"{\n" \
			"FragColor = uColor;\n" \
		"}\n";

	// Step 2 : Create the Shader Object
	GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);

	// Step 3 : Give the Shader Source Code to the Shader Object
	glShaderSource(fragmentShaderObject, 1, (const GLchar**)&fragmentShaderSourceCode, NULL);

	// Step 4 : Compile the Shader Programmatically
	glCompileShader(fragmentShaderObject);

	// Step 5 : Shader Compilation Error Checking
	status = 0;
	infoLogLength = 0;
	szInfoLog = NULL;

	glGetShaderiv(fragmentShaderObject, GL_COMPILE_STATUS, &status);
	if (status == GL_FALSE)
	{
		glGetShaderiv(fragmentShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0)
		{
			szInfoLog = (GLchar*)malloc(infoLogLength * sizeof(GLchar));
			if (szInfoLog != NULL)
			{
				glGetShaderInfoLog(fragmentShaderObject, infoLogLength, NULL, szInfoLog);
				fprintf(gpFile, "Fragment Shader Compilation Log : %s \n", szInfoLog);

				free(szInfoLog);
				szInfoLog = NULL;
			}
		}

		[self release];
		[self uninitialize];
		[NSApp terminate:self];
	}

	// Create, Attach and Link Shader Program Object
	shaderProgramObject = glCreateProgram();

	glAttachShader(shaderProgramObject, vertexShaderObject);
	glAttachShader(shaderProgramObject, fragmentShaderObject);

	// Bind Shader Attributes at a certain index in Shader to same index in Host Program
	glBindAttribLocation(shaderProgramObject, AMC_ATTRIBUTE_POSITION, "aPosition");

	glLinkProgram(shaderProgramObject);

	status = 0;
	infoLogLength = 0;
	szInfoLog = NULL;

	glGetProgramiv(shaderProgramObject, GL_LINK_STATUS, &status);
	if (status == GL_FALSE)
	{
		glGetProgramiv(shaderProgramObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0)
		{
			szInfoLog = (GLchar*)malloc(infoLogLength * sizeof(GLchar));
			if (szInfoLog != NULL)
			{
				glGetProgramInfoLog(shaderProgramObject, infoLogLength, NULL, szInfoLog);
				fprintf(gpFile, "Shader Program Link Log : %s \n", szInfoLog);

				free(szInfoLog);
				szInfoLog = NULL;
			}
		}

		[self release];
		[self uninitialize];
		[NSApp terminate:self];
	}

	// Get the required uniform location from the shader
	mvpMatrixUniform = glGetUniformLocation(shaderProgramObject, "uMVPMatrix");
	colorUniform = glGetUniformLocation(shaderProgramObject, "uColor");

	/*************************		GRAPH	  *************************/
	/*************************		X-Axis	  *************************/
	const GLfloat XAxis_Position[] =
	{
		1.0f, 0.0f, 0.0f,
	   -1.0f, 0.0f, 0.0f,
	};

	// Vertex array object for arrays of vertex attributes
	glGenVertexArrays(1, &vao_XAxis);

	glBindVertexArray(vao_XAxis);

	// Position
	glGenBuffers(1, &vbo_position_XAxis);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_XAxis);

	glBufferData(GL_ARRAY_BUFFER, sizeof(XAxis_Position), XAxis_Position, GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTE_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);

	/*************************		Y-Axis	  *************************/
	const GLfloat YAxis_Position[] =
	{
		0.0f,  1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
	};

	// Vertex array object for arrays of vertex attributes
	glGenVertexArrays(1, &vao_YAxis);

	glBindVertexArray(vao_YAxis);

	// Position
	glGenBuffers(1, &vbo_position_YAxis);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_YAxis);

	glBufferData(GL_ARRAY_BUFFER, sizeof(YAxis_Position), YAxis_Position, GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTE_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);

	/*************************		Horizontal Lines	*************************/
	GLfloat horizontalLines_Position[numberOfTotalLines * 2][3];
	float hX = 1.0f;
	float hY = 1.0f;

	for (int i = 0; i < numberOfLinesEachSide; i++)
	{
		horizontalLines_Position[i * 2][0] = hX;
		horizontalLines_Position[i * 2][1] = hY;
		horizontalLines_Position[i * 2][2] = 0.0f;

		horizontalLines_Position[i * 2 + 1][0] = -hX;
		horizontalLines_Position[i * 2 + 1][1] = hY;
		horizontalLines_Position[i * 2 + 1][2] = 0.0f;

		hY = hY - 0.05f;
	}

	hY = -0.05f;

	for (int i = 0; i < numberOfLinesEachSide; i++)
	{
		int base = (numberOfLinesEachSide + i) * 2;

		horizontalLines_Position[base][0] = hX;
		horizontalLines_Position[base][1] = hY;
		horizontalLines_Position[base][2] = 0.0f;

		horizontalLines_Position[base + 1][0] = -hX;
		horizontalLines_Position[base + 1][1] = hY;
		horizontalLines_Position[base + 1][2] = 0.0f;

		hY = hY - 0.05f;
	}

	// Vertex array object for arrays of vertex attributes
	glGenVertexArrays(1, &vao_horizontalLines);

	glBindVertexArray(vao_horizontalLines);

	// Position
	glGenBuffers(1, &vbo_position_horizontalLines);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_horizontalLines);

	glBufferData(GL_ARRAY_BUFFER, sizeof(horizontalLines_Position), horizontalLines_Position, GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTE_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);

	/*************************		Vertical Lines		*************************/
	GLfloat verticalLines_Position[numberOfTotalLines * 2][3];
	hX = 1.0f;
	hY = 1.0f;

	for (int i = 0; i < numberOfLinesEachSide; i++)
	{
		verticalLines_Position[i * 2][0] = hX;
		verticalLines_Position[i * 2][1] = hY;
		verticalLines_Position[i * 2][2] = 0.0f;

		verticalLines_Position[i * 2 + 1][0] = hX;
		verticalLines_Position[i * 2 + 1][1] = -hY;
		verticalLines_Position[i * 2 + 1][2] = 0.0f;

		hX = hX - 0.05f;
	}

	hX = -0.05f;

	for (int i = 0; i < numberOfLinesEachSide; i++)
	{
		int base = (numberOfLinesEachSide + i) * 2;

		verticalLines_Position[base][0] = hX;
		verticalLines_Position[base][1] = hY;
		verticalLines_Position[base][2] = 0.0f;

		verticalLines_Position[base + 1][0] = hX;
		verticalLines_Position[base + 1][1] = -hY;
		verticalLines_Position[base + 1][2] = 0.0f;

		hX = hX - 0.05f;
	}

	// Vertex array object for arrays of vertex attributes
	glGenVertexArrays(1, &vao_verticalLines);

	glBindVertexArray(vao_verticalLines);

	// Position
	glGenBuffers(1, &vbo_position_verticalLines);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_verticalLines);

	glBufferData(GL_ARRAY_BUFFER, sizeof(verticalLines_Position), verticalLines_Position, GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTE_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);

	/*************************		TRIANGLE	*************************/
	// Provide Vertex position, Color, Normals, Texco-ords etc..
	// Position
	const GLfloat triangle_Position[] =
	{
		0.0f,  0.5f, 0.0f,
	   -0.5f, -0.5f, 0.0f,
	   -0.5f, -0.5f, 0.0f,
		0.5f, -0.5f, 0.0f,
		0.5f, -0.5f, 0.0f,
		0.0f,  0.5f, 0.0f,
	};

	// Vertex array object for arrays of vertex attributes
	glGenVertexArrays(1, &vao_triangle);

	glBindVertexArray(vao_triangle);

	// Position
	glGenBuffers(1, &vbo_position_triangle);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_triangle);

	glBufferData(GL_ARRAY_BUFFER, sizeof(triangle_Position), triangle_Position, GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTE_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	/*************************		SQUARE		*************************/
	// Provide Vertex position, Color, Normals, Texco-ords etc..
	// Position
	const GLfloat rectangle_Position[] =
	{
		0.5f,  0.5f, 0.0f,
	   -0.5f,  0.5f, 0.0f,
	   -0.5f,  0.5f, 0.0f,
	   -0.5f, -0.5f, 0.0f,
	   -0.5f, -0.5f, 0.0f,
		0.5f, -0.5f, 0.0f,
		0.5f, -0.5f, 0.0f,
		0.5f,  0.5f, 0.0f
	};

	// Vertex array object for arrays of vertex attributes
	glGenVertexArrays(1, &vao_rectangle);

	glBindVertexArray(vao_rectangle);

	// Position
	glGenBuffers(1, &vbo_position_rectangle);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_rectangle);

	glBufferData(GL_ARRAY_BUFFER, sizeof(rectangle_Position), rectangle_Position, GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTE_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);

	/*************************		CIRCLE  	*************************/
	GLfloat circle_Position[numberOfPointsToDrawCircle][3];
	GLfloat angle;

	for (int i = 0; i < numberOfPointsToDrawCircle; i++)
	{
		angle = (GLfloat)(2 * M_PI * i) / numberOfPointsToDrawCircle;
		circle_Position[i][0] = (GLfloat)cos(angle) * 0.7;
		circle_Position[i][1] = (GLfloat)sin(angle) * 0.7;
		circle_Position[i][2] = 0.0f;
	}

	// Vertex array object for arrays of vertex attributes
	glGenVertexArrays(1, &vao_circle);

	glBindVertexArray(vao_circle);

	// Position
	glGenBuffers(1, &vbo_position_circle);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_circle);

	glBufferData(GL_ARRAY_BUFFER, sizeof(circle_Position), circle_Position, GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTE_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);

	// Depth related function calls..
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	// From here onwards, OpenGL code starts...
	// Tell OpenGL to choose the color to clear the screen
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// This line is analogous to glLoadIdentity in resize() for GL_PROJECTION in FFP
	perspectiveProjectionMatrix = mat4::identity();

	// Warm-up resize
	[self resize:winWidth :winHeight];

	return(0);
}

-(void)printGLInfo
{
	// Code
	fprintf(gpFile, "\n OPENGL INFORMATION \n");
	fprintf(gpFile, "*************************************************\n");
	fprintf(gpFile, "OpenGL Vender   : %s \n", glGetString(GL_VENDOR));
	fprintf(gpFile, "OpenGL Renderer : %s \n", glGetString(GL_RENDERER));
	fprintf(gpFile, "OpenGL Version  : %s \n", glGetString(GL_VERSION));
	fprintf(gpFile, "GLSL   Version  : %s \n", glGetString(GL_SHADING_LANGUAGE_VERSION));
	fprintf(gpFile, "*************************************************\n\n");
}

-(void)resize:(int)width :(int)height
{
	// Code
	// If height becomes 0 or less than 0 by accident, then assign height to 1
	if (height <= 0)
	{
		height = 1;
	}

	// Set the ViewPort
	glViewport(0, 0, (GLsizei)width, (GLsizei)height);

	// This line is analogous to glMatrixMode(GL_PROJECTION); from resize() in FFP
	// Set Perspective Projection
	perspectiveProjectionMatrix = vmath::perspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
}

-(void)display
{
	// Code
	// Clear OpenGL buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Use Shader Program Object
	glUseProgram(shaderProgramObject);

	// Transformations
	// This line is analogous to glLoadIdentity() in display() for MODELVIEW matrix
	mat4 modelViewMatrix = mat4::identity();

	mat4 translationMatrix = mat4::identity();

	mat4 scaleMatrix = mat4::identity();

	translationMatrix = vmath::translate(0.0f, 0.0f, -2.5f);

	scaleMatrix = vmath::scale(0.8f, 0.8f, 0.0f);

	modelViewMatrix = translationMatrix * scaleMatrix;	// Order is important (Matrix multiplication is non-commutative)

	// This line is analogous to glMatrixMode(GL_MODELVIEW); in display()
	mat4 modelViewProjectionMatrix = mat4::identity();

	modelViewProjectionMatrix = perspectiveProjectionMatrix * modelViewMatrix;	// Order is important

	// Send above matrix to the vertex shader in uniform
	glUniformMatrix4fv(mvpMatrixUniform, 1, GL_FALSE, modelViewProjectionMatrix);

	if (gbGraphKeyPressed)
	{
		[self drawGraph];
	}

	if (gbTriangleKeyPressed)
	{
		glUniform4fv(colorUniform, 1, vmath::vec4(1.0f, 1.0f, 0.0f, 1.0f));

		[self drawHollowTriangle];
	}

	if (gbSquareKeyPressed)
	{
		glUniform4fv(colorUniform, 1, vmath::vec4(1.0f, 1.0f, 0.0f, 1.0f));

		[self drawHollowSquare];
	}

	if (gbCircleKeyPressed)
	{
		glUniform4fv(colorUniform, 1, vmath::vec4(1.0f, 1.0f, 0.0f, 1.0f));

		[self drawHollowCircle];
	}

	if (gbZeroKeyPressed)
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}

	// Unuse Shader Program Object
	glUseProgram(0);
}

-(void)drawGraph
{
	[self drawHorizontalLines];
    [self drawVerticalLines];
    [self drawXAxisandYAxis];
}

-(void)drawHorizontalLines
{
	glUniform4fv(colorUniform, 1, vmath::vec4(0.0f, 0.0f, 1.0f, 1.0f));

	// Bind with vao_horizontalLines
	glBindVertexArray(vao_horizontalLines);

	int iCnt;

	// Draw the vertex arrays
	for (int i = 0; i < numberOfTotalLines; i++)
	{
		if (i < numberOfLinesEachSide)
			iCnt = numberOfLinesEachSide - i;
		else
			iCnt = -(i - numberOfLinesEachSide + 1);

		if (iCnt != 0 && (iCnt % 5 == 0))
			glLineWidth(2.5f);
		else
			glLineWidth(1.25f);

		glDrawArrays(GL_LINES, i * 2, 2);
	}

	// UnBind with vao_horizontalLines
	glBindVertexArray(0);
}

-(void)drawVerticalLines
{
	glUniform4fv(colorUniform, 1, vmath::vec4(0.0f, 0.0f, 1.0f, 1.0f));

	// Bind with vao_verticalLines
	glBindVertexArray(vao_verticalLines);

	int iCnt;

	// Draw the vertex arrays
	for (int i = 0; i < numberOfTotalLines; i++)
	{
		if (i < numberOfLinesEachSide)
			iCnt = numberOfLinesEachSide - i;
		else
			iCnt = -(i - numberOfLinesEachSide + 1);

		if (iCnt != 0 && (iCnt % 5 == 0))
			glLineWidth(2.5f);
		else
			glLineWidth(1.25f);

		glDrawArrays(GL_LINES, i * 2, 2);
	}

	// UnBind with vao_verticalLines
	glBindVertexArray(0);
}

-(void) drawXAxisandYAxis
{
	/*************************		X-Axis		*************************/

	glUniform4fv(colorUniform, 1, vmath::vec4(1.0f, 0.0f, 0.0f, 1.0f));

	// Bind with vao_XAxis
	glBindVertexArray(vao_XAxis);

	// Draw the vertex arrays
	glLineWidth(5.0f);
	glDrawArrays(GL_LINES, 0, 2);

	// UnBind with vao_XAxis
	glBindVertexArray(0);

	/*************************		Y-Axis		*************************/

	glUniform4fv(colorUniform, 1, vmath::vec4(0.0f, 1.0f, 0.0f, 1.0f));

	// Bind with vao_YAxis
	glBindVertexArray(vao_YAxis);

	// Draw the vertex arrays
	glLineWidth(5.0f);
	glDrawArrays(GL_LINES, 0, 2);

	// UnBind with vao_YAxis
	glBindVertexArray(0);
}

-(void) drawHollowTriangle
{
	// Bind with vao_triangle
	glBindVertexArray(vao_triangle);

	// Draw the vertex arrays
	glLineWidth(3.0f);
	glDrawArrays(GL_LINES, 0, 6);

	// UnBind with vao_triangle
	glBindVertexArray(0);
}

-(void)drawHollowSquare
{
	// Bind with vao_rectangle
	glBindVertexArray(vao_rectangle);

	// Draw the vertex arrays
	glLineWidth(3.0f);
	glDrawArrays(GL_LINES, 0, 2);
	glLineWidth(3.0f);
	glDrawArrays(GL_LINES, 2, 2);
	glLineWidth(3.0f);
	glDrawArrays(GL_LINES, 4, 2);
	glLineWidth(3.0f);
	glDrawArrays(GL_LINES, 6, 2);

	// UnBind with vao_rectangle
	glBindVertexArray(0);
}

-(void)drawHollowCircle
{
	// Bind with vao_circle
	glBindVertexArray(vao_circle);

	// Draw the vertex arrays
	glLineWidth(3.5f);
	glDrawArrays(GL_LINE_LOOP, 0, numberOfPointsToDrawCircle);

	// UnBind with vao_circle
	glBindVertexArray(0);
}

-(void)myUpdate
{
	// Code
}

-(void)uninitialize
{

    // Code
    fprintf(gpFile, "Inside uninitialize\n");

	// function declarations
	void toggleFullScreen(void);

	// Free vbo_position_verticalLines
	if (vbo_position_verticalLines)
	{
		glDeleteBuffers(1, &vbo_position_verticalLines);
		vbo_position_verticalLines = 0;
	}

	// Free vbo_position_horizontalLines
	if (vbo_position_horizontalLines)
	{
		glDeleteBuffers(1, &vbo_position_horizontalLines);
		vbo_position_horizontalLines = 0;
	}

	// Free vbo_position_YAxis
	if (vbo_position_YAxis)
	{
		glDeleteBuffers(1, &vbo_position_YAxis);
		vbo_position_YAxis = 0;
	}

	// Free vbo_position_XAxis
	if (vbo_position_XAxis)
	{
		glDeleteBuffers(1, &vbo_position_XAxis);
		vbo_position_XAxis = 0;
	}

	// Free vbo_position_circle
	if (vbo_position_circle)
	{
		glDeleteBuffers(1, &vbo_position_circle);
		vbo_position_circle = 0;
	}

	// Free vbo_position_rectangle
	if (vbo_position_rectangle)
	{
		glDeleteBuffers(1, &vbo_position_rectangle);
		vbo_position_rectangle = 0;
	}

	// Free vbo_position_triangle
	if (vbo_position_triangle)
	{
		glDeleteBuffers(1, &vbo_position_triangle);
		vbo_position_triangle = 0;
	}

	// Free vao_verticalLines
	if (vao_verticalLines)
	{
		glDeleteVertexArrays(1, &vao_verticalLines);
		vao_verticalLines = 0;
	}

	// Free vao_horizontalLines
	if (vao_horizontalLines)
	{
		glDeleteVertexArrays(1, &vao_horizontalLines);
		vao_horizontalLines = 0;
	}

	// Free vao_YAxis
	if (vao_YAxis)
	{
		glDeleteVertexArrays(1, &vao_YAxis);
		vao_YAxis = 0;
	}

	// Free vao_XAxis
	if (vao_XAxis)
	{
		glDeleteVertexArrays(1, &vao_XAxis);
		vao_XAxis = 0;
	}

	// Free vao_circle
	if (vao_circle)
	{
		glDeleteVertexArrays(1, &vao_circle);
		vao_circle = 0;
	}

	// Free vao_rectangle
	if (vao_rectangle)
	{
		glDeleteVertexArrays(1, &vao_rectangle);
		vao_rectangle = 0;
	}

	// Free vao_triangle
	if (vao_triangle)
	{
		glDeleteVertexArrays(1, &vao_triangle);
		vao_triangle = 0;
	}

	// Detach, Delete Shader Objects and Delete Shader Program Object
	// Step 1: Check whether Shader Program Object is still there
	if (shaderProgramObject)
	{
		glUseProgram(shaderProgramObject);
		GLint numShaders;

		// Step 2 : Get Number of Attached Shaders and Continue if Number Of Shaders is Greater than 0 
		glGetProgramiv(shaderProgramObject, GL_ATTACHED_SHADERS, &numShaders);
		if (numShaders > 0)
		{
			// Step 3 : Create a Buffer / Array to hold Attached Shader Object of Obtained Number of Shaders and Continue Only if malloc is Succeeded
			GLuint* pShaders = (GLuint*)malloc(numShaders * sizeof(GLuint));
			if (pShaders != NULL)
			{
				// Step 4 : Get Shader Objects into this Buffer / Array
				glGetAttachedShaders(shaderProgramObject, numShaders, NULL, pShaders);

				// Step 5 : Iterate through Obtained Number of Shaders and inside this loop Detach and Delete Every Shader from the Buffer / Array
				for (GLint i = 0; i < numShaders; i++)
				{
					glDetachShader(shaderProgramObject, pShaders[i]);
					glDeleteShader(pShaders[i]);
					pShaders[i] = 0;
				}
			}

			// Step 6 : Free the Buffer / Array
			free(pShaders);
			pShaders = 0;
		}

		// Step 7 : Delete the Shader Program Object
		glUseProgram(0);
		glDeleteProgram(shaderProgramObject);
		shaderProgramObject = 0;
	}

	// Close the log file
	if (gpFile)
	{
		fprintf(gpFile, "Program Terminated Successfully\n");
		fclose(gpFile);
		gpFile = NULL;
	}
}

-(void)dealloc
{
	// Code
	CVDisplayLinkStop(displayLink);
	CVDisplayLinkRelease(displayLink);
	[super dealloc];
}

@end

CVReturn myDisplayLinkCallback(CVDisplayLinkRef displayLinkRef,
							   const CVTimeStamp *current,
							   const CVTimeStamp *output,
							   CVOptionFlags inputFlags,
							   CVOptionFlags *outputFlags,
							   void *view)
{
	// Code
	CVReturn result = [(GLView *)view getFrameForTime:output];
	return(result);
}
